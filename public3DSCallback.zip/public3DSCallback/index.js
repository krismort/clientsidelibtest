const express = require('express');
const port = process.env.PORT || 3001;
const HTTP_PORT = port;
const HTTPS_PORT = 443;
const fs = require('fs');

const content = fs.readFileSync( "./callback.html", 'utf8' );
const bodyParser = require('body-parser');
const https = require('https');
const http = require('http');
const cors = require('cors');

const app = express(); // Initialize Express
app.use(cors()); // Allow CORS for express server
//app.use(bodyParser.json()); // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({ // to support URL-encoded bodies
  extended: true
}));
/*app.use(function(req, res, next) {
    var reqType = req.headers["x-forwarded-proto"];
    reqType == 'https' ? next() : res.redirect("https://" + req.headers.host + req.url);
});*/
if (process.env.NODE_ENV == 'production') {
  app.use(function (req, res, next) {
    res.setHeader('Strict-Transport-Security', 'max-age=8640000; includeSubDomains');
    if (req.headers['x-forwarded-proto'] && req.headers['x-forwarded-proto'] === "http") {
      return res.redirect(301, 'https://' + req.host + req.url);
    } else {
      return next();
    }
  });
}

console.log( "Started" );

app.get('/', (request, res) => {
  console.log( "get request ", request );
  const body = request.body || {};
  res.send( content.replace(':::pa-res:::', body.PaRes || '' ) );
});

app.post('/', (request, res) => {
  console.log( "post request ", request );
  const body = request.body || {};
  res.send( content.replace(':::pa-res:::', body.PaRes || '' ) );
});

app.listen(port, (err) => {
  if (err) {
    return console.log('something bad happened', err);
  }
  console.log(`server is listening on ${port}`);
});



/*try {
  https.createServer({
    key: fs.readFileSync('./private.key'),
    ca: fs.readFileSync('./cert.csr'),
    cert: fs.readFileSync('./certificate.pem')
  }, app)
  .listen(HTTPS_PORT, function() {
    console.log('Server listening on port ' + HTTPS_PORT);
  });
  http.createServer(app).listen(HTTP_PORT, function() {
    console.log('Insecure server listening on port ' + HTTP_PORT);
  });
}catch(e) {
  console.error(e);
}
*/


